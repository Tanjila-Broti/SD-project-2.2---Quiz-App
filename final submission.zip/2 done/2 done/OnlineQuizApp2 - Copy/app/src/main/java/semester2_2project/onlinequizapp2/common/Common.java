package semester2_2project.onlinequizapp2.common;

import java.util.ArrayList;
import java.util.List;

import semester2_2project.onlinequizapp2.Model.Question;
import semester2_2project.onlinequizapp2.Model.User;

/**
 * Created by dipta10 on 06-Feb-18.
 */

public class Common {
    public static String categoryID;
    public static User currentUser;
    public static List <Question> questionList = new ArrayList<>();
    
}
