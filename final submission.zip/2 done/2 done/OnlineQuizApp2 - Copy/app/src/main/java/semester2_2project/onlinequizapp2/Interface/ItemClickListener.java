package semester2_2project.onlinequizapp2.Interface;

import android.view.View;

/**
 * Created by dipta10 on 19-Jan-18.
 */

public interface ItemClickListener {
    void onClick (View view, int position, boolean isLongClick);
}
