package semester2_2project.onlinequizapp2;

/**
 * Created by Dipta on 14/2/18.
 */

public class Dummy {
    public static int fragmentName = 1;
}
