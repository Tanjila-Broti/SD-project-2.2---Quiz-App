package semester2_2project.onlinequizapp2.Interface;

/**
 * Created by dipta10 on 13-Feb-18.
 */

public interface RankingCallBack <T>{
    void callBack (T ranking);
}
